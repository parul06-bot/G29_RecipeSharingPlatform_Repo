from flask import Flask, request, render_template, redirect, session, flash, url_for
from flask_sqlalchemy import SQLAlchemy
import bcrypt

# Initialize the Flask application
app = Flask(__name__)

# Configurations for the database and secret key
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'secret_key'

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password.encode('utf-8'))

# Define the Recipe model
class Recipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.String(255), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('recipes', lazy=True))

    def __repr__(self):
        return f'<Recipe {self.name}>'

# Helper function to check if the user is logged in
def is_logged_in():
    return 'email' in session

# Home route
@app.route('/')
def home():
    return render_template('index.html')

# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email already registered. Please log in.", "danger")
            return redirect(url_for('login'))

        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

        new_user = User(name=name, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash("Registration successful! Please log in.", "success")
        return redirect(url_for('login'))

    return render_template('register.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            session['email'] = user.email
            session['name'] = user.name
            flash("Login successful!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid credentials. Please try again.", "danger")
    return render_template('login.html')

# Dashboard route
@app.route('/dashboard')
def dashboard():
    if is_logged_in():
        user = User.query.filter_by(email=session['email']).first()
        return render_template('dashboard.html', user=user)
    flash("Please log in to access the dashboard.", "warning")
    return redirect(url_for('login'))

# Logout route
@app.route('/logout')
def logout():
    session.pop('email', None)
    session.pop('name', None)
    flash("Logged out successfully!", "info")
    return redirect(url_for('home'))

# Share recipe route
@app.route('/share_recipe', methods=['GET', 'POST'])
def share_recipe():
    if not is_logged_in():
        flash("Please log in to share a recipe.", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        image_url = request.form['image_url']

        user = User.query.filter_by(email=session['email']).first()

        new_recipe = Recipe(name=name, description=description, image_url=image_url, user_id=user.id)

        db.session.add(new_recipe)
        db.session.commit()

        flash("Recipe shared successfully!", "success")
        return redirect(url_for('view_recipes'))

    return render_template('share_recipe.html')

# View all recipes shared by the user
@app.route('/view_recipes')
def view_recipes():
    if not is_logged_in():
        flash("Please log in to view your shared recipes.", "warning")
        return redirect(url_for('login'))

    user = User.query.filter_by(email=session['email']).first()
    recipes = Recipe.query.filter_by(user_id=user.id).all()
    return render_template('view_recipes.html', recipes=recipes)

# Edit recipe route
@app.route('/edit_recipe/<int:recipe_id>', methods=['GET', 'POST'])
def edit_recipe(recipe_id):
    if not is_logged_in():
        flash("Please log in to edit recipes.", "warning")
        return redirect(url_for('login'))

    recipe = Recipe.query.get_or_404(recipe_id)

    if request.method == 'POST':
        recipe.name = request.form['name']
        recipe.description = request.form['description']
        recipe.image_url = request.form['image_url']

        db.session.commit()
        flash("Recipe updated successfully!", "success")
        return redirect(url_for('view_recipes'))

    return render_template('edit_recipe.html', recipe=recipe)

# Delete recipe route
@app.route('/delete_recipe/<int:recipe_id>', methods=['POST'])
def delete_recipe(recipe_id):
    if not is_logged_in():
        flash("Please log in to delete recipes.", "warning")
        return redirect(url_for('login'))

    recipe = Recipe.query.get_or_404(recipe_id)
    
    db.session.delete(recipe)
    db.session.commit()

    flash("Recipe deleted successfully!", "success")
    return redirect(url_for('view_recipes'))

# Feedback route
@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if not is_logged_in():
        flash("Please log in to submit feedback.", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']

        flash("Thank you for your feedback!", "success")
        return redirect(url_for('feedback'))

    return render_template('feedback.html')

# About Us route
@app.route("/aboutus")
def aboutus():
    return render_template("aboutus.html")

# Meal Category Routes
@app.route("/pastry")
def pastry():
    return render_template("pastry.html")

@app.route("/ramen")
def ramen():
    return render_template("ramen.html")

@app.route("/breakfast")
def breakfast():
    return render_template("breakfast.html")

@app.route("/lunch")
def lunch():
    return render_template("lunch.html")

@app.route("/dinner")
def dinner():
    return render_template("dinner.html")

@app.route("/italian")
def italian():
    return render_template("italian.html")

@app.route('/indian_recipes')
def indian_recipes():
    return render_template('indian_recipes.html')

@app.route('/mexican_recipes')
def mexican_recipes():
    return render_template('mexican_recipes.html')

@app.route('/chinese_recipes')
def chinese_recipes():
    return render_template('chinese_recipes.html')


# Run the Flask app
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
